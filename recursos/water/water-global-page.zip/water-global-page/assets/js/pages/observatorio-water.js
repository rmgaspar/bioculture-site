(function(){
  'use strict';
  var DATA='/data/';
  var charts=[];
  function fmt(value,digits){return new Intl.NumberFormat('pt-PT',{maximumFractionDigits:digits==null?1:digits}).format(value)}
  function load(name){return fetch(DATA+name).then(function(r){if(!r.ok)throw new Error(name);return r.json()})}
  function series(data,id,m49){return data.observations.filter(function(o){return o.indicator_id===id&&o.geography.m49===m49}).sort(function(a,b){return a.year-b.year})}
  function chart(id,rows,label,color){var el=document.getElementById(id);if(!el||!window.Chart)return;charts.push(new Chart(el,{type:'line',data:{labels:rows.map(function(x){return x.year}),datasets:[{label:label,data:rows.map(function(x){return x.value}),borderColor:color,backgroundColor:color+'18',fill:true,tension:.28,pointRadius:1.5,pointHoverRadius:5,borderWidth:2}]},options:{responsive:true,maintainAspectRatio:false,interaction:{mode:'index',intersect:false},plugins:{legend:{display:false},tooltip:{callbacks:{label:function(c){return fmt(c.parsed.y,2)+'%'}}}},scales:{x:{grid:{display:false},ticks:{maxTicksLimit:7,color:'#8a9999'}},y:{grid:{color:'#edf2f1'},ticks:{color:'#8a9999',callback:function(v){return v+'%'}}}}}}))}
  Promise.all([load('water-overview.json'),load('water-countries.json'),load('water-timeseries.json'),load('water-sources.json')]).then(function(all){
    var overview=all[0],countries=all[1],timeseries=all[2],sources=all[3];
    var access=overview.headline_metrics.find(function(x){return x.indicator_id.indexOf('6_1_1')>-1});
    var stress=overview.headline_metrics.find(function(x){return x.indicator_id.indexOf('6_4_2')>-1});
    document.getElementById('global-metrics').innerHTML=[
      ['Água segura',fmt(access.value,1)+'%','da população mundial utiliza serviços de água potável geridos com segurança',access.year+' · WHO/UNICEF JMP'],
      ['Stress hídrico',fmt(stress.value,1)+'%','nível mundial de retiradas face aos recursos renováveis disponíveis',stress.year+' · FAO AQUASTAT'],
      ['Sem serviço seguro','2,1 mil milhões','de pessoas ainda não tinham água potável gerida com segurança','2024 · WHO/UNICEF JMP'],
      ['Condições normais','1 em 3','bacias hidrográficas apresentou condições normais','2024 · WMO']
    ].map(function(m){return '<article class="metric-card"><small>'+m[0]+'</small><strong>'+m[1]+'</strong><p>'+m[2]+'</p><span>'+m[3]+'</span></article>'}).join('');
    document.getElementById('global-insight').innerHTML='<strong>O retrato conjunto:</strong> o acesso seguro continua a aumentar, mas isso não elimina a pressão física sobre o recurso. As duas séries descrevem dimensões complementares e não uma relação causal direta.';
    chart('water-access-chart',series(timeseries,'sdg_6_1_1_safely_managed_drinking_water','001'),'Água potável segura','#2f8291');
    chart('water-stress-chart',series(timeseries,'sdg_6_4_2_water_stress','001'),'Stress hídrico','#a66f50');
    var select=document.getElementById('country-select');
    countries.entities.forEach(function(e){var o=document.createElement('option');o.value=e.geography.m49;o.textContent=e.geography.name;select.appendChild(o)});
    select.addEventListener('change',function(){
      var entity=countries.entities.find(function(e){return e.geography.m49===select.value});var panel=document.getElementById('country-panel');
      if(!entity){panel.innerHTML='<div class="empty-state"><strong>Escolha uma geografia</strong><span>Os indicadores e a evolução aparecerão aqui.</span></div>';return}
      function card(id,label){var x=entity.latest[id];return '<article class="country-value"><small>'+label+'</small>'+(x?'<strong>'+fmt(x.value,1)+'%</strong><p>'+x.year+(x.flags.estimated?' · valor assinalado como estimado':'')+'</p>':'<strong>—</strong><p>Sem valor publicado nesta seleção.</p>')+'</article>'}
      panel.innerHTML='<div class="country-summary">'+card('sdg_6_1_1_safely_managed_drinking_water','Água potável gerida com segurança')+card('sdg_6_4_2_water_stress','Stress hídrico')+'<p class="country-note">Último valor disponível para cada indicador; os anos podem não coincidir.</p></div>';
    });
    var cards=[
      ['WMO · 2024','Um ciclo mais errático','Apenas um terço das bacias hidrográficas apresentou condições normais; todas as regiões glaciares registaram perdas pelo terceiro ano consecutivo.','https://public.wmo.int/resources/publication-series/state-of-global-water-resources/state-of-global-water-resources-2024'],
      ['JMP · 2000–2024','O acesso melhora, a desigualdade permanece','A cobertura mundial de água potável gerida com segurança chegou a cerca de 74%, mas 2,1 mil milhões de pessoas continuavam sem esse nível de serviço.','https://washdata.org/report/jmp-2025-wash-households'],
      ['FAO / UN-Water','A média esconde os extremos','O stress hídrico mundial permaneceu relativamente estável, enquanto algumas regiões enfrentam níveis severos de escassez.','https://www.unwater.org/publications/progress-level-water-stress-2024-update']
    ];
    document.getElementById('report-grid').innerHTML=cards.map(function(c){return '<article class="report-card"><span class="tag">'+c[0]+'</span><strong>'+c[1]+'</strong><p>'+c[2]+'</p><a href="'+c[3]+'" target="_blank" rel="noopener">Consultar relatório ↗</a></article>'}).join('');
    document.getElementById('source-links').innerHTML=sources.sources.filter(function(s){return s.id!=='unsd_sdg_global_database'}).map(function(s){return '<a href="'+s.url+'" target="_blank" rel="noopener">'+s.organisation+' ↗</a>'}).join('');
  }).catch(function(){document.getElementById('global-metrics').innerHTML='<p class="loading">Não foi possível carregar os dados. Tente novamente.</p>'});
})();
